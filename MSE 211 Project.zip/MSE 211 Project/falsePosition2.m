function [ flam, fturb, xlam, xturb, iterlam, iterturb ] = falsePosition2( xL, xU, err, xold )
%Laminar calculations
iterlam = 1;
while(iterlam >= 0)
   xlam = xU - (dislam(xU)*(xL - xU))/(dislam(xL) - dislam(xU));
   flam = dislam(xlam);
   ea = abs((xlam - xold)/xlam)*100;
   if (ea < err)
      break;
   end
   if (dislam(xL)*dislam(xlam) < 0)
      xU = xlam;
   else
   if (dislam(xL)*dislam(xlam) > 0)
      xL = xlam;
   end
   end
   xold = xlam;
   iterlam = iterlam + 1;
end

%Turbulent calculations
iterturb = 1;
while(iterturb >= 0)
   xturb = xU - (disturb(xU)*(xL - xU))/(disturb(xL) - disturb(xU));
   fturb = disturb(xturb);
   ea = abs((xturb - xold)/xturb)*100;
   if (ea < err)
      break;
   end
   if (disturb(xL)*disturb(xturb) < 0)
 	  xU = xturb;
   else
   if (disturb(xL)*disturb(xturb) > 0)
    xL = xturb;
   end
   end
   xold = xturb;
   iterturb = iterturb + 1;
end

end

