function f = disturb(c)
global g m;
%y0 is initial condition
y0 = 7.68;
t = 0;
% Found using Maple software
%f = 7.68 + (m*log(tanh(sqrt(g*m*c)*t/m)-1)/2*c) + (m*log(tanh(sqrt(g*m*c)*t/m)+1)/2*c);
f = 

end

