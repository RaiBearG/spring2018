function [ output_args ] = newtonInter( input_args )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here


end

