function [ ylam,yturb ] = rungeKutta( c,h,t )
%Create arrays for both ylam and yturb for plotting
%Create an iterative process from t=0 to t=tfinal with step size(h) 
%that stores all x values
yold1 = 0;
yold2 = 0;
ylam = yold1;
yturb = yold2;
%t is total time
for i=0:h:t-h
  %Laminar
  k1lam = velocitylam(c,i);
  k2lam = velocitylam(c,i+0.5*h);
  k3lam = velocitylam(c,i+0.5*h);
  k4lam = velocitylam(c,i+h);
  ylam = [ylam (yold1 + (1/6)*(k1lam + 2*k2lam + 2*k3lam + k4lam)*h)];
  yold1 = ylam;
  
  %Turbulent
  k1turb = velocityturb(c,i);
  k2turb = velocityturb(c,i+0.5*h);
  k3turb = velocityturb(c,i+0.5*h);
  k4turb = velocityturb(c,i+h);
  yturb = [yturb (yold2 + (1/6)*(k1turb + 2*k2turb + 2*k3turb + k4turb)*h)];
  yold2 = yturb;
end

end

