function [ output_args ] = thirdOrder( input_args )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here


end

