function [ylam,time] = euler( c,h,t )
%Create arrays for both ylam and yturb for plotting
%Create an iterative process from t=0 to t=tfinal with step size(h) 
%that stores all x values
yold1 = 0;
yold2 = 0;
ylam = yold1;
yturb = yold2;
time = [0:h:t];
%t is total time
for i=0:h:t-h
  %Laminar
  ynew = yold1 + velocitylam(c,i)*h;
  ylam = [ylam ynew];
  %Turbulent
%   yturb = [yturb (yold2 + velocityturb(c,i)*h)];
  yold1 = ylam;
%   yold2 = yturb;
end
end

