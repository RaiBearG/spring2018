function [ flam, fturb, xlam, xturb, iterlam, iterturb ] = secant( xold, xi, err )
%Laminar calculations
iterlam = 1;
while(iterlam >= 0)
   xlam = xi - (dislam(xi)*(xold - xi))/(dislam(xold) - dislam(xi));
   flam = dislam(xlam);
   ea = abs((xlam - xold)/xlam)*100;
   if (ea < err)
      break;
   end
   xold = xlam;
   iterlam = iterlam + 1;
end

%Turbulent calculations
iterturb = 1;
while(iterturb >= 0)
   xturb = xi - (disturb(xi)*(xold - xi))/(disturb(xold) - disturb(xi));
   fturb = disturb(xturb);
   ea = abs((xturb - xold)/xturb)*100;
   if (ea < err)
      break;
   end
   xold = xturb;
   iterturb = iterturb + 1;
end

end
