function f = velocitylam(c,t)
global g m;

f = ((g*m)\c)*(-1 + exp(-((c\m)*t)));

end

