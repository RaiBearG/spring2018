function f = dislam(c)
global g m;
%y0 is initial condition
y0 = 7.68;
t = 4.6;

f = y0 - m*g*t/c - ((m^2)*g/(c^2))*(1 - exp(-(c*t/m)));

end

