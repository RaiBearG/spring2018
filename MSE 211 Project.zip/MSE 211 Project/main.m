clc
close all
global g m;
g = 9.81;
m = 0.25;
% [ flam, fturb, xlam, xturb, iterlam, iterturb ] = falsePosition2( 0.1, 5, 10^-4, 0 );
% xlam = xU - (dislam(xU)*(xL - xU))/(dislam(xL) - dislam(xU))
% [ylam,time] = euler( 1.5214,0.1,4.6 );
% plot(ylam,time,'-')
velocitylam(1.5214,0.5)
% grid on;