function f = velocityturb( c,t )
global g m;
% Found using Maple software
f = -(tanh(sqrt(g*m*c)*t/m)*sqrt(g*m*c))/c;

end

